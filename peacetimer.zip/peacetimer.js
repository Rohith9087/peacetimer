let twentysecBtn = document.getElementById("twentySecondsBtn");
let thirtysecBtn = document.getElementById("thirtySecondsBtn");
let fortysecBtn = document.getElementById("fortySecondsBtn");
let oneminBtn = document.getElementById("oneMinuteBtn");
let timerText = document.getElementById("timerText");

let currentInterval;

function startTimer(seconds) {
    clearInterval(currentInterval);
    let counter = seconds;
    timerText.textContent = counter + " seconds left";
    currentInterval = setInterval(function() {
        counter -= 1;
        if (counter >= 0) {
            timerText.textContent = counter + " seconds left";
        }
        if (counter <= 0) {
            clearInterval(currentInterval);
            timerText.textContent = "Your moment is done";
        }
    }, 1000);
}
twentysecBtn.addEventListener("click", function() {
    startTimer(20);
});
thirtysecBtn.addEventListener("click", function() {
    startTimer(30);
});
fortysecBtn.addEventListener("click", function() {
    startTimer(40);
});
oneminBtn.addEventListener("click", function() {
    startTimer(60);
});